require 'test_helper'

class BookieOddTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
