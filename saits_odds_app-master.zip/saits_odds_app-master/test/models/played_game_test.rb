require 'test_helper'

class PlayedGameTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
