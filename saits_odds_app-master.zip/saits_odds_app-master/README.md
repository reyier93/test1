# README

Detta är repo för SAITS odds app

Casekursen för Högskolan dalarna.
