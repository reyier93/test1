class PlayedGame < ApplicationRecord
end
