class BookieOdd < ApplicationRecord
end
